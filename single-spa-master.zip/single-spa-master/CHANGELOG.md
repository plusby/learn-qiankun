# Changelog

See https://github.com/single-spa/single-spa/releases for what has changed in each version of single-spa.
