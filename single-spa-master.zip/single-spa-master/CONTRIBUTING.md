# Contributing to single-spa

Want to contribute to single-spa? There are a few things you need to know.

We wrote a **[contribution guide](https://single-spa.js.org/docs/contributing-overview.html)** to help you get started.
