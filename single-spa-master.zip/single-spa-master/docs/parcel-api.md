# Parcel API

This page has moved. Find the [Single-spa Parcels API](https://single-spa.js.org/docs/parcels-api.html) documentation on the single-spa website.
