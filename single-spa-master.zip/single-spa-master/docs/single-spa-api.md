# single-spa API

This page has moved. Find the [single-spa API](https://single-spa.js.org/docs/api.html) documentation on the single-spa website.
