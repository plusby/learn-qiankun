# single-spa documentation

This page has moved. Find the single-spa documentation on the [single-spa website](https://single-spa.js.org/docs/getting-started-overview.html)
