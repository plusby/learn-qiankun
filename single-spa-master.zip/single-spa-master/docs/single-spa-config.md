# Single spa config

This page has moved. Find the [single-spa config](https://single-spa.js.org/docs/configuration.html) documentation on the single-spa website.
