# Migrating existing SPAs

This page has moved. Find ["Migrating existing SPAs"](https://single-spa.js.org/docs/migrating-existing-spas.html) on the single-spa website.
