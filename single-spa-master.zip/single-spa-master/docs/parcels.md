# Parcels

This page has moved. Find the [Single-spa Parcels](https://single-spa.js.org/docs/parcels-overview.html) documentation on the single-spa website.
