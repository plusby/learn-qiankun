# Separating out applications

This page has moved. Find the [Separating Applications](https://single-spa.js.org/docs/separating-applications.html) documentation on the single-spa website.
