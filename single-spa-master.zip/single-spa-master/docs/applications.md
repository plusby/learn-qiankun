# Registered applications

This page has moved. Find ["Building Applications"](https://single-spa.js.org/docs/building-applications.html) on the single-spa website.
