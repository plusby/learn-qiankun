# Root application

Root application has been renamed to single-spa-config, to make it clear that the root application/single-spa-config is very different from single-spa-applications

## Single-spa-config

[single-spa-config](https://single-spa.js.org/docs/configuration.html)

## Single-spa-applications

[applications](https://single-spa.js.org/docs/building-applications.html)
