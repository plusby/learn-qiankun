export const isInBrowser = typeof window !== "undefined";
