window.__SINGLE_SPA_DEVTOOLS__ = {};
global.__DEV__ = true;
