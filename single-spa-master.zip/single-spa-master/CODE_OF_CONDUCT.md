# Code of Conduct

Single-spa has adopted a Code of Conduct that we expect project participants to adhere to. Please [read the full text](https://single-spa.js.org/docs/code-of-conduct.html) so that you can understand what actions will and will not be tolerated.
